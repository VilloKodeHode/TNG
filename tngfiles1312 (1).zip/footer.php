<?php global $text, $tng_version, $flags; ?>
<hr size="1" />
<?php
	$flags['basicfooter'] = true;
	echo tng_footer($flags);
?>
<br/>
