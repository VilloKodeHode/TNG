<?php
$gedpath = "gedcom";
$saveimport = "1";
$tngimpcfg['rrnum'] = "100";
$tngimpcfg['readmsecs'] = "750";
$assignnames = "";
$tngimpcfg['defimpopt'] = "0";
$tngimpcfg['chdate'] = "0";
$tngimpcfg['livingreqbirth'] = "0";
$tngimpcfg['maxlivingage'] = "110";
$tngimpcfg['maxprivyrs'] = "";
$tngimpcfg['maxdecdyrs'] = "";
$tngimpcfg['maxmarriedage'] = "0";
$locimppath['photos'] = "";
$locimppath['histories'] = "";
$locimppath['documents'] = "";
$locimppath['headstones'] = "";
$locimppath['other'] = "";
$wholepath = "0";
$tngimpcfg['privnote'] = "";
$tngimpcfg['coerce'] = "0";
?>