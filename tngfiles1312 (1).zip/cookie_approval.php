<script type="text/javascript">
  window.CookieHinweis_options  = {
  message: '<?php echo $text['cookieuse']; ?><br/>',
  agree: '<?php echo $text['understand']; ?>',
  learnMore: '&bull; <?php echo $text['viewpolicy']; ?>',
  link: '<?php echo getURL( "data_protection_policy", 0 ); ?>',
  theme: 'hell-unten-rechts'  //other options: dark-top, dark-bottom
 };
</script>
<script type="text/javascript" src="<?php echo $cms['tngpath']; ?>js/cookiebanner.js"></script>