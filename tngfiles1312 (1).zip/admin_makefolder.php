<?php
include("begin.php");
include("adminlib.php");
$textpart = "setup";
//include("getlang.php");
include("$mylanguage/admintext.php");

header("Content-type:text/html; charset=" . $session_charset);
if( $link ) {
	$admin_login = 1;
	include("checklogin.php");
	if( $assignedtree ) {
		echo $admtext['norights'];
		exit;
	}
}

if( file_exists($newfolder) )
	echo $admtext['fexists'];
elseif( (file_exists( $oldfolder ) && @rename( $oldfolder, $newfolder )) || @mkdir( $newfolder, 0755 ) )
	echo $admtext['success'];
else
	echo $admtext['fmanual'];
?>
