<style type="text/css">
#tngnav a {font-size:11px}
#tabs a {font-size:11px}
</style>